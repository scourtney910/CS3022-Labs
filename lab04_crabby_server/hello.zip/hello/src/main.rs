use std::{
    fs,
    net::{TcpListener, TcpStream},
    io::{BufReader, prelude::*},
};

fn main() {
    let listener = TcpListener::bind("127.0.0.1:7878").unwrap();

    for stream in listener.incoming() {
        let stream = stream.unwrap();
        
        handle_connection(stream);
    }
}

fn handle_connection(mut stream: TcpStream) {
    let buf_reader = BufReader::new(&mut stream);
    let request_line = buf_reader.lines().next().unwrap().unwrap();
    
    // Extract the path from the request line
    // Example: "GET /page1.html?message=Hello HTTP/1.1" -> "/page1.html"
    let path = request_line
        .split_whitespace()
        .nth(1)
        .unwrap_or("/")
        .split('?')  // Remove query parameters
        .next()
        .unwrap_or("/");

    // Match the path to determine which file to serve
    let (status_line, filename) = match path {
        "/"           => ("HTTP/1.1 200 OK", "index.html"),
        "/index.html" => ("HTTP/1.1 200 OK", "index.html"),
        "/page1.html" => ("HTTP/1.1 200 OK", "page1.html"),
        "/page2.html" => ("HTTP/1.1 200 OK", "page2.html"),
        _             => ("HTTP/1.1 404 NOT FOUND", "404.html"),
    };

    let contents = fs::read_to_string(filename).unwrap_or_else(|_| {
        String::from("<h1>404 - File Not Found</h1>")
    });

    let length = contents.len();

    let response = format!(
        "{status_line}\r\nContent-Length: {length}\r\n\r\n{contents}"
    );

    stream.write_all(response.as_bytes()).unwrap();
    stream.flush().unwrap();
}
